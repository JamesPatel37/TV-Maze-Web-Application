angular.module('show.controller', [])
	.controller('ShowController', function ($scope, show) {
		$scope.show = show;
	});
